#!/usr/bin/env bash

set -euo pipefail

if [ -n "$DEVKITPRO" ]; then
    echo "Sourcing DEVKITPRO environment variables..."
    source ${DEVKITPRO}/devkita64.sh
fi

PREFIX=/opt/devkitpro/devkitA64

SOURCE_DIR=$(pwd -P)/libgloss
TARGET=${TARGET:-aarch64-none-elf}
BUILD_DIR=${SOURCE_DIR}/build
export CFLAGS="-O2 -ffunction-sections -fdata-sections"

die() {
	echo "Error: $*" >&2
	exit 1
}

[[ -x "$SOURCE_DIR/configure" ]] || \
	die "run this script from the newlib repository root containing libgloss/configure"

libc_cv_compiler_isystem=""
for subdir in include include-fixed; do
    dir=`$CC -print-file-name=$subdir`
    # -print-file-name echoes back the argument unchanged when it can't find the path
    if test -n "$dir" && test "$dir" != "$subdir"; then
        libc_cv_compiler_isystem="$libc_cv_compiler_isystem -isystem $dir"
    fi
done
libc_cv_compiler_isystem="$libc_cv_compiler_isystem -isystem /opt/devkitpro/devkitA64/aarch64-none-elf/include"
export libc_cv_compiler_isystem

mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

if [[ ! -f configured-libgloss ]]; then
	echo "Configuring local libgloss source for $TARGET"
	env -u CC -u CXX \
		../configure --target="$TARGET" --host="$TARGET" --prefix="$PREFIX" --enable-multilib
	touch configured-libgloss
fi

if [[ ! -f built-libgloss ]]; then
	echo "Building libgloss"
	make
	touch built-libgloss
fi

if [[ ! -f installed-libgloss ]]; then
	echo "Installing libgloss to $PREFIX"
	make install -j1
	touch installed-libgloss
fi

echo "libgloss for $TARGET installed in $PREFIX"

unset CFLAGS
unset libc_cv_compiler_isystem
